package com.example.buscaminas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private RadioButton rdbFacil, rdbNormal, rdbDificil, rdbMinaClasica, rdbBomber, rdbDinamita, rdbGranada, rdbMinaSubmarina, rdbCoctelMolotov;
    private int[] datos = new int[] {0,7};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rdbFacil = findViewById(R.id.rdbFacil);
        rdbNormal = findViewById(R.id.rdbNormal);
        rdbDificil = findViewById(R.id.rdbDificil);

        rdbMinaClasica = findViewById(R.id.rdbMinaClasica);
        rdbBomber = findViewById(R.id.rdbBomber);
        rdbDinamita = findViewById(R.id.rdbDinamita);
        rdbGranada = findViewById(R.id.rdbGranada);
        rdbMinaSubmarina = findViewById(R.id.rdbMinaSubmarina);
        rdbCoctelMolotov = findViewById(R.id.rdbCoctelMolotov);

        Button btnJugar = findViewById(R.id.btnJugar);
        btnJugar.setOnClickListener(this::datos);
    }

    private void jugar() {
        Intent intent = new Intent(this, Juego.class);
        intent.putExtra("dificultad", datos[0]);
        intent.putExtra("bomba", datos[1]);
        startActivity(intent);
    }

    private void datos(View view) {
        if (rdbFacil.isChecked()) {
            datos[0] = 8;
        } else if(rdbNormal.isChecked()) {
            datos[0] = 12;
        } else if(rdbDificil.isChecked()) {
            datos[0] = 16;
        } else {
            Toast.makeText(this, "Debe seleccionar una dificultad", Toast.LENGTH_LONG).show();
        }

        if (rdbMinaClasica.isChecked()) {
            datos[1] = 0;
        } else if (rdbBomber.isChecked()) {
            datos[1] = 1;
        } else if (rdbDinamita.isChecked()) {
            datos[1] = 2;
        } else if (rdbGranada.isChecked()) {
            datos[1] = 3;
        } else if (rdbMinaSubmarina.isChecked()) {
            datos[1] = 4;
        } else if (rdbCoctelMolotov.isChecked()) {
            datos[1] = 5;
        } else {
            Toast.makeText(this, "Debe seleccionar el tipo de bomba", Toast.LENGTH_LONG).show();
        }

        if (datos[0] != 0 && datos[1] != 7) {
            jugar();
        }
    }
}