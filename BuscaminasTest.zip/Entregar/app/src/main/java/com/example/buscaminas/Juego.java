package com.example.buscaminas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Juego extends AppCompatActivity {
    private int dificultad, tipoBomba, bombas, segundos, alto, ancho;
    private int[][] mapa;
    private TextView lblTiempo, lblBanderas;
    private ConstraintLayout tablero;
    private Temporizador reloj;
    private Random ran = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        dificultad = getIntent().getIntExtra("dificultad", 8);
        tipoBomba = getIntent().getIntExtra("bomba", 1);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);

        lblTiempo = findViewById(R.id.lblTiempo);
        tablero = findViewById(R.id.tablero);
        lblBanderas = findViewById(R.id.lblBanderas);

        lblBanderas.setText("Banderas:\n0");
        bombas();
        generarMapa();
        iniciarTiempo();
    }

    private void generarMapa() {
        mapa = new int[dificultad][dificultad];
        alto = tablero.getHeight();
        ancho = tablero.getWidth();

        GridLayout g = new GridLayout(getApplicationContext());
        GridLayout.LayoutParams param=new GridLayout.LayoutParams();
        param.setMargins(0,0,0,0);
        param.height= ViewGroup.LayoutParams.MATCH_PARENT;
        param.width= ViewGroup.LayoutParams.MATCH_PARENT;
        g.setRowCount(dificultad);
        g.setColumnCount(dificultad);
        g.setLayoutParams(param);
        tablero.addView(g);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ancho/dificultad,alto/dificultad);
        layoutParams.setMargins(0,0,0,0);
        /*
        * Tablero 8 x 8 = 64 con 10 > 6,4
        * Tablero 12 x 12 = 144 con 30 > 4,8
        * Tablero 16 x 16 = 256 con 60 > 4,26...
        */
        int minas = bombas, seleccion = 0;
        int[] foto = new int[] {R.drawable.blanco1,R.drawable.blanco2,R.drawable.blanco3};
        switch (dificultad) {
            case 8:seleccion = 0;break;
            case 12:seleccion = 1;break;
            case 16:seleccion = 2;break;
        }
        for (int i = 0; i < dificultad; i++) {
            for (int j = 0; j < dificultad; j++) {
                if (minas > 0) {
                    switch (dificultad) {
                        case 8:
                            switch (ran.nextInt(5)) {
                                case 4:mapa[i][j] = 1;minas--;break;
                                default:mapa[i][j] = 0;break;
                            }
                            break;
                        case 12:
                            switch (ran.nextInt(4)) {
                                case 3:mapa[i][j] = 1;minas--;break;
                                default:mapa[i][j] = 0;break;
                            }
                            break;
                        case 16:
                            switch (ran.nextInt(4)) {
                                case 2:mapa[i][j] = 1;minas--;break;
                                default:mapa[i][j] = 0;break;
                            }
                            break;
                    }

                    System.out.print(String.valueOf(mapa[i][j]) + " ");
                } else {
                    mapa[i][j] = 0;
                    System.out.print(String.valueOf(mapa[i][j]) + " ");
                }
            }
            System.out.print("   " + String.valueOf(minas));
            System.out.println();
        }

        for (int i = 0; i < dificultad; i++) {
            for (int j = 0; j < dificultad; j++) {
                if (mapa[i][j] == 1) {
                    ImageButton boton = new ImageButton(this);
                    boton.setImageResource(foto[seleccion]);
                    boton.setPadding(1,1,1,1);
                    boton.setOnClickListener(this::explotar);
                    boton.setOnLongClickListener(this::ponerBandera);
                    g.addView(boton);
                }  else {
                    ImageButton botonVacio = new ImageButton(this);
                    botonVacio.setPadding(1,1,1,1);
                    botonVacio.setImageResource(foto[seleccion]);
                    botonVacio.setOnClickListener(this::comprobar);
                    botonVacio.setOnLongClickListener(this::ponerBandera);
                    g.addView(botonVacio);
                }
            }
        }

    }

    private boolean ponerBandera(View view) {
        System.out.println("poner bandera");
        return true;
    }

    private void explotar(View view) {
        System.out.println("bum");
    }

    private void comprobar(View view) {
        System.out.println("nada");
    }

    private void iniciarTiempo() {
        reloj = new Temporizador();
        reloj.start();
    }

    private void pararTiempo() {
        reloj.setBandera(false);
    }

    private void bombas() {
        switch (dificultad) {
            case 8: bombas = 10;break;
            case 12: bombas = 30;break;
            case 16: bombas = 60;break;
            default: bombas = 10;break;
        }
    }

    public class Temporizador extends Thread{
        private boolean bandera = true;

        public boolean isBandera() {
            return bandera;
        }

        public void setBandera(boolean bandera) {
            this.bandera = bandera;
        }

        @Override
        public void run() {
            while (bandera) {
                segundos++;
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                lblTiempo.setText("Tiempo: \n" + segundos);
            }
        }
    }
}